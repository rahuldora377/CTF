import os
import pickle
import hmac
import hashlib

def fun(name,password):
    s = {"username":name,"password":password}
    safecode = pickle.dumps(s)
    digest = hmac.new(bytes('here_goes_your_shared_key','utf-8'),safecode,hashlib.sha1).hexdigest()
    with open("users.json","wb") as f:
        f.write(safecode+bytes('-','utf-8'))
        f.write(bytes(digest,'utf-8'))
    return safecode

if __name__ == '__main__':
    u = input("Username : ")
    p = input("Password : ")
    fun(u,p)
