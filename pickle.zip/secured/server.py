import os
import pickle
import hmac
import hashlib

def reverse_fun():
      with open("users.json","rb") as f:
          data = f.read()
          try:
            safecode,recvd_digest = data.split(bytes('-','utf-8'))
          except ValueError:
            return "Not enough arguments or corrupted json"

      digest = hmac.new(bytes('here_goes_your_shared_key','utf-8'),safecode,hashlib.sha1).hexdigest()

      if hmac.compare_digest(recvd_digest,bytes(digest,'utf-8')):
          d = pickle.loads(safecode)
          return d
      else:
          return "Invalid Hash"     
      d = pickle.loads(data)
      return d

if __name__ == '__main__':
      print(reverse_fun())
